# cac-windows

Claude Code 的 Windows 隐私保护工具 — 二进制补丁抹除中国特征，遥测正常流转。

当前版本：`1.0.28`，适配 Claude Code `2.1.294`。

## 功能

- **隐私补丁** — 自动补丁 claude.exe，抹除时区（Asia/Shanghai → TZ）、语言（zh → en）、UTC 偏移（+08:00 → +00:00）
- **时区对齐** — 系统提示词日期和时区跟随 TZ 环境变量
- **代理支持** — HTTP / SOCKS5 / SOCKS5H 代理配置
- **Profile 隔离** — 每个环境独立配置、Home、AppData、缓存、临时目录和身份清单
- **生命周期保护** — 切换 Profile 前强制结束旧 Claude 会话，避免身份与配置混用
- **启动完整性** — 精确锁定 Claude Code 版本，校验补丁标记和 claude.exe SHA-256
- **网络验收** — 检查代理可达性、socks5h 远程 DNS 语义和子进程环境继承
- **A/B 验收** — 验证 Profile 默认 Home、配置、AppData、TEMP/TMP 不交叉
- **Native/硬件证据** — 单独记录 Windows CIM、注册表、磁盘、网卡等主机共享面
- **Profile 清理** — 只清理当前 Profile，不修改全局 `.claude` 或全局凭据
- **零依赖** — 只需要 Node.js 和 PowerShell

## 环境要求

- Windows 10 / 11
- Node.js ≥ 14
- PowerShell 5.1（系统自带）或 PowerShell 7（推荐）
- Claude Code 2.1.294（`npm i -g @anthropic-ai/claude-code@2.1.294`，或在 cac 菜单里一键安装）

## 安装

```powershell
npm i -g cac-windows --registry https://registry.npmjs.org --force
cac
```

> 新版 npm（11+）默认拦截安装脚本，会看到 `install scripts not yet covered by allowScripts` 警告——这是正常的。包已经装好了，只是补丁没在 `npm i` 阶段完成。**装完运行一次 `cac`** 即可，它会解包 Claude Code 二进制、打补丁、设 PATH。
>
> 如果想让 npm 直接放行（可选）：
> ```powershell
> npm i -g cac-windows --allow-scripts=cac-windows,@anthropic-ai/claude-code --registry https://registry.npmjs.org --force
> ```

## 快速开始

`cac` 首次运行自动完成初始化：定位 claude.exe（未安装则自动安装 2.1.294）、生成 wrapper、把 `%USERPROFILE%\.cac\bin` 加到用户 PATH 中 npm 目录之前、应用补丁并登记二进制 SHA-256。之后进入菜单：

```
1. 启动 Claude Code
2. 环境管理        （切换 / 创建 / 删除环境，设时区、代理，清空回收站）
3. 版本更新并应用补丁
4. 清理追踪数据    （换号用）
5. 查看状态
6. 网络隔离检查
7. Profile A/B 隔离测试
8. Native/硬件边界证据
0. 退出
```

上下键选择，回车确认，Esc 返回。

配置完成后**重开一个终端**，之后直接敲 `claude` 即可。wrapper 会先校验当前 Claude Code 版本、补丁完整性和 SHA-256，再绑定当前 Profile 的 `CLAUDE_CONFIG_DIR`、`HOME`、`USERPROFILE`、`APPDATA`、`LOCALAPPDATA`、`TEMP`、`TMP` 后启动 claude.exe。Claude 会话运行时不能切换 Profile；切换操作会先强制结束旧 Claude 进程，防止两个 Profile 混用。

菜单顶部会显示 `claude 命令: 走 cac` 还是 `绕过 cac`。绕过说明 PATH 顺序有问题——先重开终端，仍不行就手动检查用户 PATH。

## 隐私补丁覆盖范围

| 泄露点 | 补丁方式 |
|--------|---------|
| 系统提示词日期 | 日期函数 → 跟随 TZ 环境变量 |
| 系统提示词时区 | resolvedOptions().timeZone → TZ 环境变量 |
| 系统时区名缓存 | 时区缓存函数 → TZ 环境变量 |
| 系统语言检测 | 语言缓存函数 → 固定 "en" |
| UTC 偏移 | getTimezoneOffset() → 固定 +00:00 |
| 日期格式化 locale | toLocaleDateString → 固定 "en" |
| 语言环境变量 | LANG = en_US.UTF-8 |

补丁签名与 Claude Code 版本绑定，当前支持 2.1.294。新版本发布后需要重新提取签名。

## Profile 文件布局

每个 `%USERPROFILE%\.cac\envs\<name>` 都包含独立运行面：

```text
<name>\
├─ .claude\           # CLAUDE_CONFIG_DIR、会话、设置、Statsig
├─ home\              # USERPROFILE/HOME
├─ AppData\           # APPDATA/LOCALAPPDATA
├─ cache\             # 应用缓存边界
├─ temp\              # TEMP/TMP
├─ xdg\               # XDG_CONFIG_HOME/XDG_CACHE_HOME
├─ audit\             # 网络和 A/B 验收证据
├─ identity.json      # Profile 身份清单
└─ uuid/stable_id/user_id/machine_id/hostname/mac_address
```

Windows 版本的隔离边界是**进程级 Profile 隔离**。它能阻止 Claude 进程通过默认 Home、配置、AppData、缓存和临时路径读取其他 Profile，但不改变 Windows 内核、物理网卡、磁盘序列号、BIOS/SMBIOS、CPUID 或 Native `DeviceIoControl` 返回值。`E:\claude` 中的 Native/硬件报告仍应作为独立观测证据，不能用本项目的 Node/PowerShell 结果替代。

菜单中的 **Native/硬件边界证据** 会把 Windows CIM、MachineGuid、磁盘、卷、处理器和物理网卡等主机共享面写入 `audit/native-hardware-check.json`；敏感标识只保存存在性、长度和 SHA-256。报告会明确标记 CPUID、Native `DeviceIoControl`、内核驱动和物理内存未被本项目采集或隔离。

> **为什么必须通过 `claude` wrapper（或 cac 菜单）启动？** claude.exe 是 Bun 打包的单文件程序，内置了预编译的 JSC 字节码。默认情况下运行时直接执行字节码，**内嵌的 JS 源码根本不会被读取，补丁等于没打**。wrapper 启动时会设置 `BUN_JSC_useCodeCache=false`，强制 Bun 放弃字节码、回退到（已打补丁的）源码执行。代价是启动慢约 0.3 秒。直接双击或用绝对路径运行 claude.exe 不会带上这个变量，补丁不生效。

## 致谢

本项目基于 [cac](https://github.com/nmhjklnm/cac) 改造，原项目提供了完整的 macOS / Linux 支持。

## License

MIT
